package com.group2.detecthief;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DetecthiefApplication {

	public static void main(String[] args) {
		SpringApplication.run(DetecthiefApplication.class, args);
	}

}
